<!-- start of footer -->
    <div class="footer">
      <div>copywrite 2020 - all rights reserved - domain name</div> <span>template by OS templates</span>
    </div>
    <!-- End of footer -->