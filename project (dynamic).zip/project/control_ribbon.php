<div class="control_ribbon_style" style="border-radius: 10px;">
	<div class="control_option" style="margin-right: 2%;"><a href="backend/logout_process.php">Log-out</a></div>
	<div class="control_option"><a href="signup.php">Add Auther</a></div>
	<div class="control_option"><a href="add_content.php">Add Content</a></div>
	<div class="control_option"><a href="admin_bash.php">Admin Bash</a></div>
	<div class="control_option"><a href="index.php">Visit Site</a></div>
</div>