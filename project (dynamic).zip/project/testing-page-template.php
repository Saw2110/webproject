<!DOCTYPE html>
<html>
<head>
  <title>Portofolio</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="control_ribbon_style.css">
</head>
<body>
<?php include("header.php"); ?>
<br><br><br>
<!-- start of content -->
<div class="porto-container">
  
  <div></div>

</div>
<!-- main container <div> -->
  <div class="filler"></div>
<!-- end of content -->
<?php include("footer.php"); ?>


</div>
</div>
</body>
</html>