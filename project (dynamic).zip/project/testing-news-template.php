<!DOCTYPE html>
<html>
<head>
  <title>Notice</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="control_ribbon_style.css">
</head>
<body>
<?php include("header.php"); ?>
<br><br><br>
<!-- start of content -->
<div class="news-container">
 <div class="md-u-filler"></div>

  <div class="news-main-body">
    <div class="news-msg-body">

      <div class="bg-u-filler"></div>

      <div align="center" class="news-title"><h2>Title</h2></div>
      <div class="sm-filler"></div>

      <div align="center" class="news-msg">
        <p>This is a dummy notice.</p>
      </div>

      <div class="bg-filler"></div>
    </div>
  </div>

<div class="md-u-filler"></div>
</div>
<!-- main container <div> -->
  <div class="filler"></div>
</div>
<!-- end of content -->
<?php include("footer.php"); ?>


</div>
</body>
</html>