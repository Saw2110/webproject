<!DOCTYPE html>
<html>
<head>
  <title>Post</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="control_ribbon_style.css">
</head>
<body>
<?php include 'header.php'; ?>
<br><br><br>
<!-- start of content -->
<div class="post-container">
<div class="filler"></div>

  <div class="post">
  <div align="center" class="post-title"><h2>title</h2></div>
  <div class="filler"></div>
  <div align="center" class="post-img"><img src=""></div>
  <div class="filler"></div>
  <div align="center" class="post-content">
    <p>this is for paragraph</p>
    <div align="center" class="post-sub-title"><h3>sub-title</h3></div><br>

    <div class="filler"></div>
  </div>
  </div>

<!-- main container <div> -->
<div class="filler"></div>
</div>
<!-- end of content -->
<?php include 'footer.php'; ?>

</body>
</html>